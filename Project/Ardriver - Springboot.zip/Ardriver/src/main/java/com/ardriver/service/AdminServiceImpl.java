package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Driver;
import com.ardriver.model.Driver_;
import com.ardriver.model.Ride;
import com.ardriver.model.Ride_;
import com.ardriver.repository.CustomerRepository;
import com.ardriver.repository.DriverRepository;
import com.ardriver.repository.RideRepository;
import com.ardriver.specifications.FilterSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private RideRepository rideRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Response getTripsAndProfits() {
        Response response = new Response();
        response.setStatus(true);

        YearMonth currentYearMonth = YearMonth.now();
        YearMonth previousYearMonth = currentYearMonth.minusMonths(1);
        LocalDate startDate = previousYearMonth.atDay(1);
        LocalDate endDate = previousYearMonth.atEndOfMonth();
//        System.out.println(startDate + " => " + endDate);

        Map<String, Object> tripAndProfitMap = new HashMap<>();
        tripAndProfitMap.put("currentMonthTrips", rideRepository.countRidesForCurrentMonth());
        tripAndProfitMap.put("preMonthTrips", rideRepository.countRidesForPreviousMonth(startDate, endDate));
        tripAndProfitMap.put("currentMonthProfit", rideRepository.sumFareForCurrentMonth());
        tripAndProfitMap.put("prevMonthProfit", rideRepository.sumFareForPreviousMonth(startDate, endDate));

        response.setResponseData(tripAndProfitMap);

        return response;
    }

    @Override
    public Response getDashBoardData(){
        Response response = new Response();
        response.setStatus(true);

        YearMonth currentYearMonth = YearMonth.now();
        YearMonth previousYearMonth = currentYearMonth.minusMonths(1);
        LocalDate startDate = previousYearMonth.atDay(1);
        LocalDate endDate = previousYearMonth.atEndOfMonth();

        Map<String, Object> dashboardDataMap = new HashMap<>();

        dashboardDataMap.put("totalTrips", rideRepository.count());
        dashboardDataMap.put("tripsPercentage", rideRepository.calculateTripsPercentage()-100);
        dashboardDataMap.put("totalCurrentYearRevenue", rideRepository.calculateCurrentYearRevenue());
        dashboardDataMap.put("revenuePercentage", rideRepository.calculateRevenuePercentageCurrentAndPreviousMonth()-100);
        dashboardDataMap.put("totalDrivers", driverRepository.count());
        dashboardDataMap.put("driverPercentage", -10.32);
        dashboardDataMap.put("totalCustomer", customerRepository.count());
        dashboardDataMap.put("customerPercentage", 26.45);

        response.setResponseData(dashboardDataMap);

        return response;
    }

    @Override
    public Response getAllRides(LocalDate fromDate, LocalDate toDate, Integer pageNo, Integer entryPerPage) {
        Response response = new Response();
        response.setStatus(true);

        System.out.println("FROM DATE TO TODATE => "+fromDate + " => " + toDate);

        Sort sort = Sort.by(Sort.Order.desc(Ride_.DATE));
        // for paging
        Pageable pageable = PageRequest.of(pageNo, entryPerPage, sort);
        Page<Ride> ridesPage = null;

        if (fromDate != null && toDate != null) {
            ridesPage = rideRepository.getRidesBetweenDates(fromDate, toDate, pageable);
        } else {
            ridesPage = rideRepository.findAll(pageable);
        }

        List<Ride> rideList = ridesPage.getContent();

        response.setResponseData(rideList);
        response.setPageable(ridesPage.getTotalPages());

        return response;
    }

    @Override
    public Response getTopDrivers() {
        Response response = new Response();
        response.setStatus(true);

        List<Object[]> topDrivers = rideRepository.findTopDrivers();

        response.setResponseData(topDrivers);
        return response;
    }

    @Override
    public Response getGraphData() {
        Response response = new Response();
        response.setStatus(true);

        List<Object[]> sumOfFareMonthWise = rideRepository.findSumOfFareMonthWise();
        response.setResponseData(sumOfFareMonthWise);

        return response;
    }
}
