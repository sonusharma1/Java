package com.ardriver.service;

import com.ardriver.dto.AuthenticationDto;
import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Driver;
import com.ardriver.model.Ride;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface DriverService {
    Boolean addDriver(Driver driver);

    Driver findDriver(Integer id);

    Boolean updateDriverName(Integer driverId, String driverName);

    @Transactional
    Boolean deleteDriverById(Integer driverId);

    // Sorting and Limiting
    List<Driver> getTopThreeDriverWithHighestRating();

    Boolean isRegisteredPartner(AuthenticationDto authDto);

    List<Ride> findRides(Integer driverId);

    Response findAllDrivers(String filterTxt, Integer page, Integer size);

    Response findCarByDriverId(Integer driverId);

}
