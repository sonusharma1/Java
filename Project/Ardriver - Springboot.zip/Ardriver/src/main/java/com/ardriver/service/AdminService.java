package com.ardriver.service;

import com.ardriver.dto.Response;

import java.time.LocalDate;

public interface AdminService {

    Response getTripsAndProfits();

    public Response getDashBoardData();

    Response getAllRides(LocalDate fromDate, LocalDate toDate, Integer pageNo, Integer entryPerPage);

    Response getTopDrivers();

    Response getGraphData();
}
