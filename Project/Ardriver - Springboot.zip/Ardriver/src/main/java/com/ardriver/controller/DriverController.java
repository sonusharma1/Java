package com.ardriver.controller;

import com.ardriver.dto.AuthenticationDto;
import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Ride;
import com.ardriver.service.CarService;
import com.ardriver.service.DriverService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/partners")
@CrossOrigin(origins = "*")
public class DriverController {

    @Autowired
    private CarService carService;
    @Autowired
    private DriverService driverService;
    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping("/register")
    public ResponseEntity<Response> registerDriver(@Valid @RequestBody Car car) {
        Response response = carService.addCar(car);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginPartner(@Valid @RequestBody AuthenticationDto authDto) {
        if (driverService.isRegisteredPartner(authDto))
            return new ResponseEntity<>("Login Successfull", HttpStatus.OK);
        else
            return new ResponseEntity<>("Incorrect email or password", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/rides/{driverId}")
    public List<Ride> getDriverRides(@PathVariable("driverId") Integer driverId) {
        return driverService.findRides(driverId);
    }

    @PutMapping("/update/car/status")
    public ResponseEntity<Response> updateCarStatus(@RequestBody Map<String, Object> request) {
        Response response = carService.updateCarStatus(
                (Integer) request.get("driverId"),
                (String) request.get("carStatus")
        );
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/findAll")
    public ResponseEntity<Response> getDrivers(
            @RequestParam(name = "filterTxt", required = false, defaultValue = "") String filterTxt,
            @RequestParam(name = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(name = "size", required = false, defaultValue = "5") Integer size
    ) {
        System.out.println("size => " + size + "   pageNo => " + page);
        Response response = driverService.findAllDrivers(filterTxt, page, size);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getCar/{driverId}")
    public ResponseEntity<Response> getCar(@PathVariable("driverId") Integer driverId) {
        return new ResponseEntity<>(driverService.findCarByDriverId(driverId),HttpStatus.OK);
    }

    @PutMapping("/update")
    public ResponseEntity<Response> updateDriver(@Valid @RequestBody Car car) {
        Response response = carService.updateCar(car);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }
}
