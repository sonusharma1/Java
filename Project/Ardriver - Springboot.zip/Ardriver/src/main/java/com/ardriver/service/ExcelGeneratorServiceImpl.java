package com.ardriver.service;

import com.ardriver.model.Customer;
import com.ardriver.model.Ride;
import com.ardriver.repository.RideRepository;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;

@Service
public class ExcelGeneratorServiceImpl implements ExcelGeneratorService{

    @Autowired
    private RideRepository rideRepository;
    @Override
    public byte[] exportRideData(LocalDate fromDate, LocalDate toDate) {
        try {
            Page<Ride> ridePage = rideRepository.getRidesBetweenDates(fromDate, toDate, null);
            List<Ride> rides = ridePage.getContent();

            System.out.println("ride data => "+rides.size());

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            XSSFWorkbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Ride Report");

            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("Id");
            row.createCell(1).setCellValue("Rider");
            row.createCell(2).setCellValue("Date");
            row.createCell(3).setCellValue("Driver");
            row.createCell(4).setCellValue("Vehicle Type");
            row.createCell(5).setCellValue("Fare");

            int dataRowIndex = 1;

            for (Ride ride : rides) {
                Row dataRow = sheet.createRow(dataRowIndex++);
                dataRow.createCell(0).setCellValue(ride.getRideId());
                dataRow.createCell(1).setCellValue(ride.getCustomer().getCustomerName());
                dataRow.createCell(2).setCellValue(ride.getDate().toString());
                dataRow.createCell(3).setCellValue(ride.getCar().getDriver().getDriverName());
                dataRow.createCell(4).setCellValue(String.valueOf(ride.getCar().getCarType()));
                dataRow.createCell(5).setCellValue(ride.getFare());
            }

            workbook.write(byteArrayOutputStream);

            workbook.close();

            return byteArrayOutputStream.toByteArray();


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
