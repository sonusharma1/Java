package com.ardriver.controller;

import com.ardriver.dto.Response;
import com.ardriver.model.Customer;
import com.ardriver.repository.RideRepository;
import com.ardriver.service.EmailService;
import com.ardriver.service.ExcelGeneratorService;
import com.ardriver.service.RideService;
import com.ardriver.utility.LocationConverter;
import com.ardriver.utility.PdfGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/ride")
@CrossOrigin(origins = "*")
public class RideController {

    @Autowired
    private RideService rideService;

    @Autowired
    private LocationConverter locationConverter;

    @Value("${map.token}")
    private String mapAccessToken;

    @Value("${map.url}")
    private String mapMyIndiaUrl;

    @Autowired
    private RideRepository rideRepository;

    @Autowired
    private PdfGenerator pdfGenerator;

    @Autowired
    private ExcelGeneratorService excelGeneratorService;

    @Autowired
    private EmailService emailService;

    @PostMapping("/book")
    public ResponseEntity<Response> bookRide(@RequestBody Map<String, Object> rideRequest) {
        Response response = rideService.bookRide(rideRequest);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/map/{address}")
    public ResponseEntity<?> mapApiTest(@PathVariable("address") String address) {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "Bearer " + mapAccessToken);
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> httpEntity = new HttpEntity<>(null, httpHeaders);
        ResponseEntity<Map> exchange = new RestTemplate().exchange(mapMyIndiaUrl + address, HttpMethod.GET, httpEntity, Map.class);

        return new ResponseEntity<>(exchange.getBody(), HttpStatus.OK);
    }

    @GetMapping("/getPrices")
    public ResponseEntity<Response> getCabPrices(
            @RequestParam(name = "srcLocation", required = true, defaultValue = "") String srcLocation,
            @RequestParam(name = "destLocation", required = true, defaultValue = "") String destLocation
    ) {
        Response response = rideService.getPriceOfRide(srcLocation, destLocation);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/sendRideBookedEmail/{rideId}")
    public void send(@PathVariable("rideId") Integer rideId) {
        emailService.sendRideBookedEmail(rideId);
    }

    @GetMapping("/generate-pdf")
    public ResponseEntity<byte[]> generatePdf() throws Exception {

        byte[] pdfBytes = pdfGenerator.generatePdf2(rideRepository.findById(65).get());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    }

    @GetMapping("/export-ride-data")
    public ResponseEntity<byte[]> exportRideData2(
            @RequestParam(name = "fromDate", required = false, defaultValue = "") LocalDate fromDate,
            @RequestParam(name = "toDate", required = false, defaultValue = "") LocalDate toDate
    ) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "example.xlsx");

        return new ResponseEntity<>(excelGeneratorService.exportRideData(fromDate,toDate), headers, HttpStatus.OK);
    }
}
