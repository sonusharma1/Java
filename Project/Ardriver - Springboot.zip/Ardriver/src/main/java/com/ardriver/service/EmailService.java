package com.ardriver.service;

import com.ardriver.model.Ride;

public interface EmailService {

    void sendRideBookedEmail(Integer rideId);
}
