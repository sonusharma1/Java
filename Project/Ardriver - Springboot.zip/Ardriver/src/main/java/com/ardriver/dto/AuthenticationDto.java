package com.ardriver.dto;

import jakarta.validation.constraints.Email;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthenticationDto {

    @Email
    private String email;
    //@Min(8)
    private String password;
}
