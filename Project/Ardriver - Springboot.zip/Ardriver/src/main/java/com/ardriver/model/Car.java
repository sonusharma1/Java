package com.ardriver.model;

import com.ardriver.utility.CarStatus;
import com.ardriver.utility.CarType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class Car {

    @Id
    @SequenceGenerator(name = "car_id_generator", sequenceName = "car_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "car_id_generator")
    @Column(name = "car_id")
    private Integer carId;

    @Column(length = 10, nullable = false)
    @Pattern(regexp = "[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}", message = "Invalid Car Number Plate!!!")
    @NotNull
    private String licenseNumberPlate;
    @NotNull
    private CarType carType;

    private Double latitude;
    private Double longitude;

    @OneToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @Valid
    private Driver driver;

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    List<Ride> rides;

    private CarStatus carStatus;

    @Override
    public String toString() {
        return "Car{" +
                "carId=" + carId +
                ", licenseNumberPlate='" + licenseNumberPlate + '\'' +
                ", carType=" + carType +
                //", driver=" + driver +
                //", rides=" + rides +
                '}';
    }

    public void addRide(Ride ride) {
        rides.add(ride);
        ride.setCar(this); // Set the CAR reference in the ride
    }
}
