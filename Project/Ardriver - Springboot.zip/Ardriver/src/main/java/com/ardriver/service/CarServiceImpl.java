package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Car_;
import com.ardriver.model.Customer;
import com.ardriver.model.Customer_;
import com.ardriver.repository.CarRepository;
import com.ardriver.repository.DriverRepository;
import com.ardriver.specifications.FilterSpecification;
import com.ardriver.utility.CarStatus;
import com.ardriver.utility.CarType;
import com.ardriver.utility.DistanceCalculator;
import jakarta.persistence.EntityManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.beans.Beans;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    public static final Logger log = LogManager.getLogger(CarServiceImpl.class);

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private DriverRepository driverRepository;


    //@Transactional
    @Override
    public Response addCar(Car car) {
        Response response = new Response();
        try {
            // car.setDriver(driver);
            carRepository.save(car);
            log.info("car details saved into DB :)");
            response.setStatus(true);
            response.setResponseData(car);
            return response;

        } catch (Exception exception) {
            response.getErrorMessages().add("Unable to add car");
            log.error("Error in addCar {}", exception);
            return response;
        }
    }

    @Override
    @Transactional
    public Car findCarById(int id) {
        Optional<Car> car = carRepository.findById(id);
        if (car.isPresent()) {
            return car.get();
        } else {
            log.error("Car not found with id=" + id);
            return null;
        }
    }

    @Override
    @Transactional
    public List<Car> findCarByType(CarType carType) {
        List<Car> carList = carRepository.findByCarType(carType);
        if (carList == null) {
            log.info("cars are not available of " + carType + " type");
            return null;
        } else {
            return carList;
        }

    }

    @Override
    @Transactional
    public List<Car> findNearByCab(Double userLatitude, Double userLongitude) {
        double searchRadiusKm = 1.0;
        List<Car> carList = carRepository.findAll();

        carList = carList.stream().filter((car) -> {
            double distance = DistanceCalculator.haversineDistance(userLatitude, userLongitude, car.getLatitude(), car.getLongitude());
            return distance <= searchRadiusKm;
        }).toList();

        if (carList == null) {
            log.warn("No cars available at this location");
        }
        return carList;
    }

    @Transactional
    @Override
    public Response updateCarLocation(Integer carId, Double[] newLocation) {
        Response response = new Response();
        Optional<Car> car = carRepository.findById(carId);
        if (car.isPresent()) {
            Car car1 = car.get();
            car1.setLatitude(newLocation[0]);
            car1.setLongitude(newLocation[1]);
            log.info("Car Location Updated.");
            response.setStatus(true);
            response.setResponseData(car1);
            return response;
        }
        response.getErrorMessages().add("car location not changed");
        log.error("Something went wrong!!! Car location not changed.");
        return response;
    }

    @Transactional
    @Override
    public Response updateCarStatus(Integer driverId, String carStatus) {
        Response response = new Response();
        Car car = carRepository.findByDriverId(driverId);
        if (car != null) {
            car.setCarStatus(CarStatus.valueOf(carStatus));
            log.info("Car status updated");
            response.setStatus(true);
            response.setResponseData(car);
            return response;
        } else {
            log.error("car status updation failed");
            response.getErrorMessages().add("car status updation failed");
            return response;
        }

    }

    @Override
    public Response findAllCars(String filterTxt, Integer page, Integer size) {
        Response response = new Response();
        response.setStatus(true);

        Sort sort = Sort.by(Sort.Order.asc(Car_.CAR_ID));
        // for paging
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Car> carPage = carRepository.findAll(
                FilterSpecification.searchOnAllFields(filterTxt,Car.class),
                pageable
        );

        List<Car> carList = carPage.getContent();
        response.setResponseData(carList);
        response.setPageable(carPage.getTotalPages());

        return response;
    }

    @Transactional
    @Override
    public Response updateCar(Car car) {
        Response response = new Response();
        try {

            Car carToUpdate = carRepository.findById(car.getCarId()).get();
            if (carToUpdate != null) {
                BeanUtils.copyProperties(car,carToUpdate);
                carRepository.save(carToUpdate);
                log.info("car details updated");
                response.setStatus(true);
                response.setResponseData(car);
                return response;
            }
            else {
                response.getErrorMessages().add("Unable to update car");
                response.setStatus(false);
                return response;
            }


        } catch (Exception exception) {
            response.getErrorMessages().add("Unable to add car");
            log.error("Error in updateCar {}", exception);
            return response;
        }
    }
}
