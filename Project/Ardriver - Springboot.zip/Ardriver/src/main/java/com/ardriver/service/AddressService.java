package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Address;

public interface AddressService {

    public Response addAddress(Address address);
}
