package com.ardriver.controller;

import com.ardriver.dto.Response;
import com.ardriver.model.Address;
import com.ardriver.service.AddressService;
import com.ardriver.service.AdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private Environment env;
    @Autowired
    private AddressService addressService;

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public ResponseEntity<Response> adminLogin(
            @RequestParam(name = "username", required = false, defaultValue = "") String username,
            @RequestParam(name = "password", required = false, defaultValue = "") String password
    ) {
        Response response = new Response();
        String adminUsername = env.getProperty("admin.username");
        String adminPassword = env.getProperty("admin.password");
        if (adminUsername.equals(username) && adminPassword.equals(password)) {
            response.setStatus(true);
        } else {
            response.setStatus(false);
        }
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/addNewAddress")
    public ResponseEntity<Response> addNewAddress(@Valid @RequestBody Address address) {
        Response response = addressService.addAddress(address);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/getTripsAndProfit")
    public ResponseEntity<Response> getTripsAndProfit() {
        return new ResponseEntity<>(adminService.getTripsAndProfits(), HttpStatus.OK);
    }

    @GetMapping("/getAllRides")
    public ResponseEntity<Response> getAllRides(
            @RequestParam(name = "fromDate", required = false, defaultValue = "") LocalDate fromDate,
            @RequestParam(name = "toDate", required = false, defaultValue = "") LocalDate toDate,
            @RequestParam(name = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(name = "size", required = false, defaultValue = "5") Integer size
    ) {
        return new ResponseEntity<>(adminService.getAllRides(fromDate, toDate, page, size), HttpStatus.OK);
    }

    @GetMapping("/getDashboardData")
    public ResponseEntity<Response> getDashboardData() {
        return new ResponseEntity<>(adminService.getDashBoardData(), HttpStatus.OK);
    }

    @GetMapping("/getTopDrives")
    public ResponseEntity<Response> getTopDrivers() {
        return new ResponseEntity<>(adminService.getTopDrivers(), HttpStatus.OK);
    }

    @GetMapping("/getGraphData")
    public ResponseEntity<Response> getGraphData() {
        return new ResponseEntity<>(adminService.getGraphData(), HttpStatus.OK);
    }
}
