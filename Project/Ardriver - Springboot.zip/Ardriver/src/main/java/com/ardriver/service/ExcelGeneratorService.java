package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Customer;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

public interface ExcelGeneratorService {

    byte[] exportRideData(LocalDate fromDate, LocalDate toDate);
}
