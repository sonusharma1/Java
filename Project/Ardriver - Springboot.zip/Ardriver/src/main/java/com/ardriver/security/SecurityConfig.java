// package com.ardriver.security;
//
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.security.authentication.AuthenticationManager;
// import org.springframework.security.config.Customizer;
// import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
// import org.springframework.security.config.annotation.web.builders.HttpSecurity;
// import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
// import org.springframework.security.config.http.SessionCreationPolicy;
// import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.security.web.SecurityFilterChain;
// import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
// import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
//
// @Configuration
// @EnableWebSecurity
// public class SecurityConfig {
//
//     @Autowired
//     private CustomUserDetailService userDetailService;
//     @Autowired
//     private JwtAuthEntryPoint authEntryPoint;
//
//     @Bean
//     public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//         http
//                 .csrf(c -> c.disable())
//                 .exceptionHandling(e -> e.authenticationEntryPoint(authEntryPoint))
//                 .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//                 .authorizeHttpRequests(authorize -> authorize
//                         // .requestMatchers("/customer/register", "/customer/login").permitAll()
//                         .requestMatchers("/*/*", "/customer/*").permitAll()
//                         .anyRequest().authenticated()
//                 )
//                 // .userDetailsService(userDetailService)
//                 .httpBasic(Customizer.withDefaults());
//         http.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
//
//         return http.build();
//     }
//
//     @Bean
//     public PasswordEncoder passwordEncoder() {
//         return new BCryptPasswordEncoder();
//     }
//
//     @Bean
//     public AuthenticationManager authenticationManager(
//             AuthenticationConfiguration authenticationConfiguration
//     ) throws Exception {
//         return authenticationConfiguration.getAuthenticationManager();
//     }
//
//     @Bean
//     public JwtAuthenticationFilter jwtAuthenticationFilter() {
//         return new JwtAuthenticationFilter();
//     }
// }
