// package com.ardriver.security;
//
// import com.ardriver.model.Customer;
// import com.ardriver.model.Driver;
// import com.ardriver.repository.CustomerRepository;
// import com.ardriver.repository.DriverRepository;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
//
// import java.util.Collections;
// import java.util.Optional;
//
// import static com.ardriver.model.Ride_.customer;
//
// @Service
// public class CustomUserDetailService implements UserDetailsService {
//
//     @Autowired
//     private CustomerRepository customerRepository;
//     @Autowired
//     private DriverRepository driverRepository;
//
//     @Override
//     public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//         Optional<Customer> optionalCustomer = customerRepository.findByEmail(username);
//         if (optionalCustomer.isPresent()) {
//             Customer customer = optionalCustomer.get();
//             return new User(customer.getEmail(), customer.getPassword(), Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")));
//         } else {
//             Optional<Driver> optionalDriver = driverRepository.findByEmail(username);
//             if (optionalDriver.isPresent()) {
//                 Driver driver = optionalDriver.get();
//                 return new User(driver.getEmail(), driver.getPassword(), Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")));
//             }
//             else
//                 throw new UsernameNotFoundException("User Not Found!!");
//         }
//     }
// }
