package com.ardriver.service;

import com.ardriver.model.Ride;
import com.ardriver.repository.RideRepository;
import com.ardriver.utility.PdfGenerator;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import static com.ardriver.constants.RideConstant.TRIP_INVOICE_PDF;

@Service
public class EmailServiceImpl implements EmailService{

    @Autowired
    private RideRepository rideRepository;

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Autowired
    private PdfGenerator pdfGenerator;

    @Override
    public void sendRideBookedEmail(Integer rideId) {

        try {

            Ride ride = rideRepository.findById(rideId).get();

            // Generate Invoice attachment
            byte[] invoiceBytes = pdfGenerator.generatePdf2(ride);

            // CC
            String[] ccEmail = {"s.sharma@direction.biz","ssff7570@gmail.com"};
            //String[] ccEmail = {"m.konar@direction.biz","s.borde@direction.biz", "s.sharma@direction.biz"};

            MimeMessage mimeMessage = javaMailSender.createMimeMessage();

            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
            messageHelper.setFrom(fromEmail);
            messageHelper.setCc(ccEmail);
            messageHelper.setTo(ride.getCustomer().getEmail());

            String emailBody = """
                                        
                    <h5>Thank you for booking a ride with us. We appreciate your trust in our services. 
                    Your ride is confirmed, and our driver will be there on time. Safe travels!
                                        
                    Best regards,
                    Ardriver</h5>
                    """;

            messageHelper.setSubject("Ride Details");
            messageHelper.setText(emailBody,true);
            messageHelper.addAttachment(TRIP_INVOICE_PDF, new ByteArrayResource(invoiceBytes));

            javaMailSender.send(mimeMessage);

            System.out.println("Ride book mail sent");

        } catch (Exception e) {
            System.out.println("Ride book mail not sent"+e);
        }

    }
}
