package com.ardriver.utility;


import com.ardriver.model.Address;
import com.ardriver.model.Ride;
import com.ardriver.repository.AddressRepository;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.border.DottedBorder;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.property.HorizontalAlignment;
import com.itextpdf.layout.property.TextAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.itextpdf.layout.border.Border.SOLID;

@Service
public class PdfGenerator {

    @Autowired
    private AddressRepository addressRepository;

    public byte[] generatePdf(Ride ride) {

        DeviceRgb headingColor = new DeviceRgb(26, 32, 44);
        DeviceRgb textColor = new DeviceRgb(89, 93, 98);
        DeviceRgb bgColor = new DeviceRgb(235, 239, 255);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        PdfWriter pdfWriter = new PdfWriter(byteArrayOutputStream);
        PdfDocument pdfDocument = new PdfDocument(pdfWriter);

        Document document = new Document(pdfDocument);

        Paragraph paragraph = new Paragraph();
        paragraph.add("Trip Invoice");
        paragraph.setTextAlignment(TextAlignment.CENTER);
        paragraph.setPaddingBottom(10);
        paragraph.setFontSize(15);
        document.add(((Paragraph) createParagraph("Trip Invoice")));

        Paragraph invoiceDatePara = new Paragraph().add("Invoice Date : " + ride.getDate()).setTextAlignment(TextAlignment.RIGHT).setFontColor(headingColor);
        document.add(invoiceDatePara);

        document.add(new Paragraph("Driver Details").setFontColor(headingColor).setMarginBottom(-2).setPaddingBottom(0));
        Paragraph driverPara = new Paragraph()
                .add(
                        ride.getCar().getDriver().getDriverName() + "\n" +
                                ride.getCar().getCarType() + "\n" +
                                ride.getCar().getLicenseNumberPlate()
                )
                .setFontColor(textColor)
                .setPaddingTop(0);
        document.add(driverPara);

        document.add(new Paragraph("Customer Details").setFontColor(headingColor).setMarginBottom(-2).setPaddingTop(5));
        Paragraph customerPara = new Paragraph()
                .add(
                        ride.getCustomer().getCustomerName() + "\n" +
                                ride.getCustomer().getMobileNo() + "\n" +
                                ride.getCustomer().getEmail()
                )
                .setFontColor(textColor)
                .setPaddingTop(0);
        document.add(customerPara);

        Table table2 = new Table(1);
        table2.addCell(new Cell().add("Pickup Address : \n").setBorder(Border.NO_BORDER).setFontColor(headingColor))
                .addCell(new Cell().add(getAddress(ride.getSourceLocation())).setBorder(Border.NO_BORDER).setFontColor(textColor)).setWidthPercent(70);
        table2.addCell(new Cell().add("Destination Address : \n").setBorder(Border.NO_BORDER).setFontColor(headingColor))
                .addCell(new Cell().add(getAddress(ride.getDestLocation())).setBorder(Border.NO_BORDER).setFontColor(textColor));
        table2.setMarginBottom(15);
        table2.setMarginTop(15);
        document.add(table2);

        Table fareTable = new Table(2);
        fareTable.addCell(new Cell().add("Description ").setBorder(Border.NO_BORDER).setFontColor(headingColor).setBackgroundColor(bgColor).setPaddings(5, 3, 5, 3));
        fareTable.addCell(new Cell().add("Amount").setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setFontColor(headingColor).setBackgroundColor(bgColor).setPaddings(5, 3, 5, 3));

        fareTable.addCell(new Cell().add("Ride Fee ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor, 0.5f)).setPaddings(5, 3, 5, 3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 95 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor, 0.5f)).setPaddings(5, 3, 5, 3));

        fareTable.addCell(new Cell().add("CGST 2.5% ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor, 0.5f)).setPaddings(5, 3, 5, 3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 2.5 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor, 0.5f)).setPaddings(5, 3, 5, 3));

        fareTable.addCell(new Cell().add("SGST 2.5% ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(headingColor, 0.5f)).setPaddings(5, 3, 5, 3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 2.5 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(headingColor, 0.5f)).setPaddings(5, 3, 5, 3));

        fareTable.addCell(new Cell().add("Sub Total ").setBorder(Border.NO_BORDER));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare())).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER));

        fareTable.setMarginTop(20);
        document.add(fareTable);

        document.close();
        return byteArrayOutputStream.toByteArray();
    }

    public byte[] generatePdf2(Ride ride) {

        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            PdfWriter pdfWriter = new PdfWriter(byteArrayOutputStream);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);

            Document document = new Document(pdfDocument);

            Table logoTable = new Table(1);
            Image logo = new Image(ImageDataFactory.create("C://Users/s.sharma/Downloads/ardriver-logo.png"));
            logo.setHeight((float) (23*1.5));
            logo.setWidth((float) (80*1.5));
            logo.setHorizontalAlignment(HorizontalAlignment.RIGHT);
            logoTable.addCell(new Cell().add(logo).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT));
            logoTable.setMarginBottom(30);
            logoTable.setTextAlignment(TextAlignment.RIGHT);
            document.add(logoTable);

            Table table = new Table(2);

//            table.addCell(new Cell().add(logo).setFontSize(20).setBorder(Border.NO_BORDER));

            Table table1 = new Table(1);
            table.addCell(new Cell().add(table1).setBorder(Border.NO_BORDER).setMargin(0));

            table1.addCell(new Cell().add(createThinPara("Invoice No")).setBorder(Border.NO_BORDER));
            table1.addCell(new Cell().add(createBoldPara(String.valueOf(ride.getRideId()))).setBorder(Border.NO_BORDER));

            table1.addCell(new Cell().add(createThinPara("Driver")).setBorder(Border.NO_BORDER).setPaddingTop(20));
            table1.addCell(new Cell().add(createBoldPara(ride.getCar().getDriver().getDriverName())).setBorder(Border.NO_BORDER).setMarginTop(10));
            table1.addCell(new Cell().add(createCustomPara(
                    ride.getCar().getCarType() + "\n" + ride.getCar().getLicenseNumberPlate())
            ).setBorder(Border.NO_BORDER));

            Table table2 = new Table(1);
            table.addCell(new Cell().add(table2).setBorder(Border.NO_BORDER).setMargin(0));

            table2.addCell(new Cell().add(createThinPara("Invoice Date")).setBorder(Border.NO_BORDER));
            table2.addCell(new Cell().add(createBoldPara(String.valueOf(ride.getDate().toString()))).setBorder(Border.NO_BORDER));

            table2.addCell(new Cell().add(createThinPara("Customer")).setBorder(Border.NO_BORDER).setPaddingTop(20));
            table2.addCell(new Cell().add(createBoldPara(ride.getCustomer().getCustomerName())).setBorder(Border.NO_BORDER).setMarginTop(10));
            table2.addCell(new Cell().add(createCustomPara(
                            ride.getCustomer().getEmail() + "\n" + ride.getCustomer().getMobileNo()
                    )
            ).setBorder(Border.NO_BORDER));

            Table locationTable = new Table(2);
            locationTable.setMarginTop(20);

//            locationTable.addCell(new Cell().setBorder(Border.NO_BORDER));

            Table pickupLocation = new Table(1);
//            pickupLocation.setMarginRight(30);
            locationTable.addCell(new Cell().add(pickupLocation).setBorder(Border.NO_BORDER));
            pickupLocation.addCell(new Cell().add(createThinPara("Pickup Location")).setBorder(Border.NO_BORDER));
            pickupLocation.addCell(new Cell().add(createCustomPara(getAddress(ride.getSourceLocation()))).setBorder(Border.NO_BORDER));

            Table destLocation = new Table(1);
            locationTable.addCell(new Cell().add(destLocation).setBorder(Border.NO_BORDER));
            destLocation.addCell(new Cell().add(createThinPara("Destination Location")).setBorder(Border.NO_BORDER));
            destLocation.addCell(new Cell().add(createCustomPara(getAddress(ride.getDestLocation()))).setBorder(Border.NO_BORDER));

            document.add(table);
            document.add(locationTable);

            DeviceRgb borderColor = new DeviceRgb(188, 199, 204);

            Table fareTable = new Table(2);
            fareTable.addCell(new Cell().add(createRegularPara("Description")).setBorder(Border.NO_BORDER).setBackgroundColor(new DeviceRgb(234, 241, 244)).setPaddings(5, 3, 5, 3));
            fareTable.addCell(new Cell().add(createRegularPara("Amount")).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBackgroundColor(new DeviceRgb(234, 241, 244)).setPaddings(5, 3, 5, 3));

            fareTable.addCell(new Cell().add(createRegularPara("Ride Fee")).setBorder(Border.NO_BORDER).setPaddings(5, 3, 5, 3));
            fareTable.addCell(new Cell().add(createRegularPara(String.valueOf(ride.getFare() * 95 / 100))).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setPaddings(5, 3, 5, 3));

            fareTable.addCell(new Cell().add(createRegularPara("CGST 2.5%")).setBorder(Border.NO_BORDER).setPaddings(5, 3, 5, 3));
            fareTable.addCell(new Cell().add(createRegularPara(String.valueOf(ride.getFare() * 2.5 / 100))).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setPaddings(5, 3, 5, 3));

            fareTable.addCell(new Cell().add(createRegularPara("SGST 2.5%")).setBorder(Border.NO_BORDER).setBorderBottom(new SolidBorder(borderColor,0.7f)).setPaddings(5, 3, 5, 3));
            fareTable.addCell(new Cell().add(createRegularPara(String.valueOf(ride.getFare() * 2.5 / 100))).setBorder(Border.NO_BORDER).setBorderBottom(new SolidBorder(borderColor,0.7f)).setTextAlignment(TextAlignment.RIGHT).setPaddings(5, 3, 5, 3));

            fareTable.addCell(new Cell().add(createBoldPara("Sub Total")).setBorder(Border.NO_BORDER).setPaddingTop(10));
            fareTable.addCell(new Cell().add(createBoldPara(String.valueOf("₹$ "+ride.getFare()))).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setPaddingTop(10));

            fareTable.setMarginTop(30);
            document.add(fareTable);

            document.close();
            return byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    IBlockElement createBoldPara(String text) throws IOException {
        Paragraph paragraph = new Paragraph(text);
        PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
        DeviceRgb color = new DeviceRgb(6, 32, 44);
        paragraph.setFontSize(12);
        paragraph.setFontColor(color);
        paragraph.setFont(font);
        paragraph.setMargin(0);
        paragraph.setPadding(0);
        return paragraph;
    }

    IBlockElement createRegularPara(String text) throws IOException {
        Paragraph paragraph = new Paragraph(text);
        PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA);
        DeviceRgb color = new DeviceRgb(44, 61, 68);
        paragraph.setFontSize(12);
        paragraph.setFontColor(color);
        paragraph.setFont(font);
        paragraph.setMargin(0);
        paragraph.setPadding(0);
        return paragraph;
    }

    IBlockElement createCustomPara(String text) throws IOException {
        Paragraph paragraph = new Paragraph(text);
        PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA);
        DeviceRgb color = new DeviceRgb(44, 61, 68);
        paragraph.setFontSize(11);
        paragraph.setFontColor(color);
        paragraph.setFont(font);
        paragraph.setMargin(0);
        paragraph.setPadding(0);
        return paragraph;
    }

    IBlockElement createThinPara(String text) throws IOException {
        Paragraph paragraph = new Paragraph(text);
        PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA);
        DeviceRgb color = new DeviceRgb(128, 138, 143);
        paragraph.setFontSize(11);
        paragraph.setFontColor(color);
        paragraph.setFont(font);
        paragraph.setMargin(0);
        paragraph.setPadding(0);
        return paragraph;
    }

    public String getAddress(String location) {

        Address address = addressRepository.findByGeoLocation(location);
        if (address != null)
            return address.getPlaceAddress();
        else
            return location;
    }

    private IBlockElement createParagraph(String text) {
        return new Paragraph(text);
    }
}
