package com.bank.emailsender;

public interface EmailService {

	String sendSimpleMail(EmailDetails details);
}
