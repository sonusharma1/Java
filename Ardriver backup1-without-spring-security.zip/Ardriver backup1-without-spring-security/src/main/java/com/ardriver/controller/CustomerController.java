package com.ardriver.controller;


import com.ardriver.dto.AuthenticationDto;
import com.ardriver.model.Car;
import com.ardriver.model.Customer;
import com.ardriver.model.Feedback;
import com.ardriver.model.Ride;
import com.ardriver.service.CarService;
import com.ardriver.service.CustomerService;
import com.ardriver.service.FeedbackService;
import com.ardriver.utility.LocationConverter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @Autowired
    private CarService carService;
    @Autowired
    private LocationConverter locationConverter;
    @Autowired
    private FeedbackService feedbackService;
    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping("/register")
    public ResponseEntity<String> registerCustomer(@Valid @RequestBody Customer customer) {
        if (customerService.saveCustomer(customer))
            return new ResponseEntity<>("registered successfully", HttpStatus.OK);
        else
            return new ResponseEntity<>("registration failed", HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/login")
    public ResponseEntity<String> customerLogin(@Valid @RequestBody AuthenticationDto customerDto) {
        if (customerService.isRegisteredCustomer(customerDto.getEmail(), customerDto.getPassword()))
            return new ResponseEntity<>("Welcome Back", HttpStatus.OK);
        else
            return new ResponseEntity<>("Incorrect Email OR Password", HttpStatus.BAD_REQUEST);
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateCustomer(@RequestBody Customer customer) {
        if (customerService.updateCustomer(customer))
            return new ResponseEntity<>("Customer Details updated", HttpStatus.OK);
        else
            return new ResponseEntity<>("Customer Updation failed", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/find/all")
    public List<Customer> findAllCustomer() {
        return customerService.findAllCustomers();
    }

    @GetMapping("/rides/{customerId}")
    public List<Ride> getCustomerRides(@PathVariable Integer customerId) {
        return customerService.findCustomerRides(customerId);
    }

    @GetMapping("/{id}")
    public Customer getCustomerDetails(@PathVariable("id") Integer customerId) {
        return customerService.findCustomerById(customerId);
    }

    @GetMapping("/nearby/cab")
    public List<Car> getNearByCabs(@RequestBody Map<String, Object> srcLocation) {
        Double[] currentLocations = locationConverter.convert((String) srcLocation.get("srcLocation"));
        return carService.findNearByCab(currentLocations[0], currentLocations[1]);
    }

    @PutMapping("/ride/feedback")
    public ResponseEntity<?> feedback(@RequestBody Map<String, Object> request) {
        if (feedbackService.giveFeedBack(
                (Integer) request.get("rideId"),
                objectMapper.convertValue(request.get("feedback"), new TypeReference<Feedback>() {
                })
        ))
            return new ResponseEntity<>("Thank You for your valuable feedback", HttpStatus.OK);
        else
            return new ResponseEntity<>("Something went wrong while saving feedback", HttpStatus.BAD_REQUEST);
    }
}
