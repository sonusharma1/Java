package com.ardriver.controller;

import com.ardriver.model.Car;
import com.ardriver.model.Ride;
import com.ardriver.service.CarService;
import com.ardriver.utility.CarType;
import com.ardriver.utility.LocationConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cab")
public class CarController {

    @Autowired
    private CarService carService;
    @Autowired
    private LocationConverter locationConverter;

    @GetMapping("/nearby")
    public List<Car> nearByCar(@RequestBody Map<String, Double> request) {
        return carService.findNearByCab(request.get("latitude"), request.get("longitude"));
    }

    @GetMapping("/type/{cab}")
    public List<Car> findCabByType(@PathVariable("cab") String cabType) {
        return carService.findCarByType(CarType.valueOf(cabType.toUpperCase()));
    }

    @PutMapping("/update/location")
    public ResponseEntity<?> updateLocation(@RequestBody Map<String, Object> request) {
        if (carService.updateCarLocation(
                (Integer) request.get("carId"),
                locationConverter.convert((String) request.get("newLocation"))
        ))
            return new ResponseEntity<>("Cab Location updated Successfully", HttpStatus.OK);
        else
            return new ResponseEntity<>("Cab Location update FAILED!!!", HttpStatus.BAD_REQUEST);
    }
}
