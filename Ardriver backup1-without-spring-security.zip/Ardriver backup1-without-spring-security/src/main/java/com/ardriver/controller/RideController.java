package com.ardriver.controller;

import com.ardriver.service.RideService;
import com.ardriver.utility.LocationConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/ride")
public class RideController {

    @Autowired
    private RideService rideService;

    @Autowired
    private LocationConverter locationConverter;

    @Value("${map.token}")
    private String mapAccessToken;

    @Value("${map.url}")
    private String mapMyIndiaUrl;

    @PostMapping("/book")
    public ResponseEntity<?> bookRide(@RequestBody Map<String, Object> rideRequest) {
        if (
                rideService.bookRide(
                        locationConverter.convert((String) rideRequest.get("srcLocation")),
                        locationConverter.convert((String) rideRequest.get("destLocation")),
                        (Integer) rideRequest.get("customerId"),
                        (String) rideRequest.get("cabPreference")
                )
        )
            return new ResponseEntity<>("Ride Booked Successfully", HttpStatus.OK);
        else
            return new ResponseEntity<>("Ride Booking Failed", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/map/{address}")
    public ResponseEntity<?> mapApiTest(@PathVariable("address") String address) {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.AUTHORIZATION,"Bearer "+mapAccessToken);
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> httpEntity = new HttpEntity<>(null,httpHeaders);
        ResponseEntity<Map> exchange = new RestTemplate().exchange(mapMyIndiaUrl + address, HttpMethod.GET, httpEntity, Map.class);

        return new ResponseEntity<>(exchange.getBody(),HttpStatus.OK);
    }
}
