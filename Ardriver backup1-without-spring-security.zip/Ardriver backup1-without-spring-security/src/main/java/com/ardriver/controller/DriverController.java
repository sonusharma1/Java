package com.ardriver.controller;

import com.ardriver.dto.AuthenticationDto;
import com.ardriver.model.Car;
import com.ardriver.model.Ride;
import com.ardriver.service.CarService;
import com.ardriver.service.DriverService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/partners")
public class DriverController {

    @Autowired
    private CarService carService;
    @Autowired
    private DriverService driverService;
    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping("/register")
    public ResponseEntity<String> registerDriver(@Valid @RequestBody Car car) {
        if (carService.addCar(car)) {
            return new ResponseEntity<>("Registered Successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Registration Failed!!", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginPartner(@Valid @RequestBody AuthenticationDto authDto) {
        if (driverService.isRegisteredPartner(authDto))
            return new ResponseEntity<>("Login Successfull", HttpStatus.OK);
        else
            return new ResponseEntity<>("Incorrect email or password", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/rides/{driverId}")
    public List<Ride> getDriverRides(@PathVariable("driverId") Integer driverId) {
        return driverService.findRides(driverId);
    }

    @PutMapping("/update/car/status")
    public ResponseEntity<?> updateCarStatus(@RequestBody Map<String, Object> request) {
        if (carService.updateCarStatus(
                (Integer) request.get("driverId"),
                (String) request.get("carStatus")
        ))
            return new ResponseEntity<>(HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
}
