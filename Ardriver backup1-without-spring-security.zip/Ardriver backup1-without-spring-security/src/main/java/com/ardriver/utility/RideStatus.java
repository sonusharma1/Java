package com.ardriver.utility;

public enum RideStatus {
    CANCELED,
    COMPLETED
}
