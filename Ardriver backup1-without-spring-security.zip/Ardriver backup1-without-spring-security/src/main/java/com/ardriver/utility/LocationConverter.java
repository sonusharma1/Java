package com.ardriver.utility;

import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class LocationConverter {

    public Double[] convert(String location) {
        String[] locationArray = location.split(",");
        return Arrays.stream(locationArray)
                .map(Double::valueOf)
                .toArray(Double[]::new);
    }
}
