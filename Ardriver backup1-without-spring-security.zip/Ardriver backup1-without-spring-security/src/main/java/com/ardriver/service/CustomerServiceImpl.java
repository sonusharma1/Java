package com.ardriver.service;

import com.ardriver.model.Customer;
import com.ardriver.model.Ride;
import com.ardriver.repository.CustomerRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Validated
public class CustomerServiceImpl implements CustomerService {

    public static final Logger log = LogManager.getLogger(CustomerServiceImpl.class);

    @Autowired
    private CustomerRepository customerRepository;

    /*@Autowired
    private CustomerDao customerDao;*/

    @Override
    public Boolean saveCustomer(Customer customer) {
        try {
            Customer savedCustomer = customerRepository.save(customer);
            log.info("customer saved :)");
            return true;
        }
        // if any error occurs
        catch (Exception ex) {
            log.error("customer not saved!!");

            while (ex.getCause() != null) {
                ex = (Exception) ex.getCause();
                /*if (ex instanceof ConstraintViolationException) {
                    Set<ConstraintViolation<?>> constraintViolations = ((ConstraintViolationException) ex).getConstraintViolations();
                    constraintViolations.forEach(error -> log.error(error.getMessage()));
                }*/
                log.error(ex.getMessage());
            }
            return false;
        }
    }

    @Transactional
    @Override
    public Boolean updateCustomer(Customer customer) {
        Customer foundCustomer = customerRepository.findById(customer.getCustomerId()).get();
        if (foundCustomer != null) {
            BeanUtils.copyProperties(customer, foundCustomer);
            log.info("Customer details updated");
            return true;
        } else {
            log.error("Customer not found");
            return false;
        }
    }

    @Transactional
    @Override
    public void deleteCustomer(Integer customerid) {
        customerRepository.deleteById(customerid);
    }

    @Override
    public List<Customer> findCustomersNameStartsWith(String customerName) {
        return customerRepository.findByCustomerNameLike(customerName + "%");
    }

    @Transactional
    @Override
    public List<Ride> findCustomerRides(Integer customerId) {
        return customerRepository.findById(customerId)
                .map(Customer::getRides)
                .orElse(Collections.emptyList());
    }

    @Override
    public List<Customer> findCustomerByNameOrEmail(String customerName, String email) {
        // return customerDao.findCustomerByNameOrEmail(customerName, email);
        // return customerRepository.findAll(CustomerSpecifications.hasNameOrEmail(customerName, email));
        return null;
    }

    @Override
    public List<Customer> findByEmailDomain(String emailDomain) {
        // return customerDao.findByEmailDomain(emailDomain);
        // OR
        // return customerRepository.findAll(CustomerSpecifications.hasEmailDomain(emailDomain));
        return null;
    }

    @Override
    public List<Customer> findCustomersByName(String customerName) {
        /*List<Customer> customerList = customerRepository.findAll(CustomerSpecifications.hasName(customerName));
        return customerList;*/
        return null;
    }

    @Override
    public Customer findCustomerById(Integer id) {
        return customerRepository.findById(id).orElse(null);
    }

    @Override
    public List<Customer> findAllCustomers() {
        return customerRepository.findAll();
    }

    // Transforming and Aggregating
    @Override
    public Map<Customer, Double> getCustomersWithTotalTraveledDist() {
        List<Customer> customers = customerRepository.findAll();

        return customers
                .stream()
                .collect(Collectors.toMap(
                        customer -> customer, // KEY
                        customer -> customer.getRides() // VALUE (returns sum(customer.List<Rides>.traveledDist)
                                .stream()
                                .mapToDouble(Ride::getTraveledDistance)
                                .sum()
                ));
    }

    @Override
    public Boolean isRegisteredCustomer(String customerEmail, String password) {
        Customer customer = customerRepository.findByEmailAndPassword(customerEmail, password);
        log.info("customer login " + (customer != null ? "success" : "failed"));
        return customer != null;
    }
}
