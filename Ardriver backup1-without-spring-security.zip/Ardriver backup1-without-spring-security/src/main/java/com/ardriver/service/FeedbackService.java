package com.ardriver.service;

import com.ardriver.model.Feedback;

public interface FeedbackService {
    Boolean giveFeedBack(Integer rideId, Feedback feedback);
}
