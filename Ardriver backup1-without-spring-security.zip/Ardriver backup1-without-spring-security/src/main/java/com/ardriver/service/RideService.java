package com.ardriver.service;

import com.ardriver.model.Customer;
import com.ardriver.model.Ride;
import com.ardriver.utility.CarType;

import java.util.List;
import java.util.Map;

public interface RideService {

    Boolean bookRide(Double[] srcLocation, Double[] destLocation, Integer customerId, String cabPreference);

    List<Ride> findRidesByCarType(CarType carType);

    List<Ride> findRidesByTraveledDistanceGreaterThan(Double distance);

    List<Ride> findRidesByRatingGreaterThan(double rating);

    List<String> getCustomersWithHighRatings(Double rating);

    // to find the average rating for each driver.
    Map<String, Double> getAvgRatingOfDrivers();

    // Mapping and Filtering
    Map<Customer, Double> getTraveledDistanceWithCustomerRatingGreaterThan(double rating);

    // Partitioning and Counting
    Map<Double, Long> getRidesOnBasisOfRating();

    // Min and Max
    Map<String, Ride> getShortestAndLongestRide();

    Map<CarType, Double> findAvgTraveledDistByCarType();
}
