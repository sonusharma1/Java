package com.ardriver.service;

import com.ardriver.model.Customer;
import com.ardriver.model.Ride;

import java.util.List;
import java.util.Map;

public interface CustomerService {
    Boolean saveCustomer(Customer customer);

    Boolean updateCustomer(Customer customer);

    void deleteCustomer(Integer customerid);

    List<Customer> findCustomersNameStartsWith(String customerName);

    List<Ride> findCustomerRides(Integer customerId);

    List<Customer> findCustomerByNameOrEmail(String customerName, String email);

    List<Customer> findByEmailDomain(String emailDomain);

    List<Customer> findCustomersByName(String customerName);

    Customer findCustomerById(Integer id);

    List<Customer> findAllCustomers();

    // Transforming and Aggregating
    Map<Customer, Double> getCustomersWithTotalTraveledDist();

    Boolean isRegisteredCustomer(String customerEmail, String password);
}
