package com.ardriver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArdriverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArdriverApplication.class, args);
		System.out.println("Ardriver App is running...");
	}

}
