package com.ardriver.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DriverDto {

    private Integer driverId;
    private String driverName;
    private String licenceNo;
    private String email;
    private String mobileNo;
    private String password;
    private Double driverRating;
}
