package com.ardriver.controller;

import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Ride;
import com.ardriver.service.CarService;
import com.ardriver.utility.CarType;
import com.ardriver.utility.LocationConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cab")
public class CarController {

    @Autowired
    private CarService carService;
    @Autowired
    private LocationConverter locationConverter;

    @GetMapping("/nearby")
    public List<Car> nearByCar(@RequestBody Map<String, Double> request) {
        return carService.findNearByCab(request.get("latitude"), request.get("longitude"));
    }

    @GetMapping("/type/{cab}")
    public List<Car> findCabByType(@PathVariable("cab") String cabType) {
        return carService.findCarByType(CarType.valueOf(cabType.toUpperCase()));
    }

    @PutMapping("/update/location")
    public ResponseEntity<Response> updateLocation(@RequestBody Map<String, Object> request) {
        Response response = carService.updateCarLocation(
                (Integer) request.get("carId"),
                locationConverter.convert((String) request.get("newLocation"))
        );
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/findAll")
    public ResponseEntity<Response> getCars(
            @RequestParam(name = "filterTxt", required = false, defaultValue = "") String filterTxt,
            @RequestParam(name = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(name = "size", required = false, defaultValue = "5") Integer size
    ) {
        System.out.println("size => " + size + "   pageNo => " + page);
        Response response = carService.findAllCars(filterTxt, page, size);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
