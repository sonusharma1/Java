package com.ardriver.controller;


import com.ardriver.dto.AuthenticationDto;
import com.ardriver.dto.FilterData;
import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Customer;
import com.ardriver.model.Feedback;
import com.ardriver.model.Ride;
import com.ardriver.repository.CustomerRepository;
import com.ardriver.service.CarService;
import com.ardriver.service.CustomerService;
import com.ardriver.service.FeedbackService;
import com.ardriver.utility.LocationConverter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "*")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @Autowired
    private CarService carService;
    @Autowired
    private LocationConverter locationConverter;
    @Autowired
    private FeedbackService feedbackService;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CustomerRepository customerRepository;
    /*@Autowired
    private JwtTokenGenerator tokenGenerator;*/

    @PostMapping("/register")
    public ResponseEntity<Response> registerCustomer(@Valid @RequestBody Customer customer) {
        // customer.setPassword(passwordEncoder.encode(customer.getPassword()));
        Response response = customerService.saveCustomer(customer);
        System.out.println(customer);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/login")
    public ResponseEntity<Response> customerLogin(
            @RequestParam(name = "email", required = false, defaultValue = "") String email,
            @RequestParam(name = "password", required = false, defaultValue = "") String password
    ) {
        Response response = customerService.isRegisteredCustomer(email, password);
        if (response.isStatus())
            return new ResponseEntity<>(response, HttpStatus.OK);
        else
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    /*@PostMapping("/login")
    public ResponseEntity<String> customerLogin(@Valid @RequestBody AuthenticationDto customerDto) {
        Authentication authenticate = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(customerDto.getEmail(), customerDto.getPassword())
        );
        if (authenticate.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(authenticate);
            String token = tokenGenerator.generateToken(authenticate);
            return new ResponseEntity<>(token, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>("Incorrect Email OR Password", HttpStatus.BAD_REQUEST);
    }*/

    @PutMapping("/update")
    public ResponseEntity<Response> updateCustomer(@Valid @RequestBody Customer customer) {
        Response response = customerService.updateCustomer(customer);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/find/all")
    public List<Customer> findAllCustomer() {
        return customerService.findAllCustomers();
    }

    @GetMapping("/rides/{customerId}")
    public List<Ride> getCustomerRides(@PathVariable Integer customerId) {
        return customerService.findCustomerRides(customerId);
    }

    @GetMapping("/{id}")
    public Customer getCustomerDetails(@PathVariable("id") Integer customerId) {
        return customerService.findCustomerById(customerId);
    }

    @GetMapping("/nearby/cab")
    public List<Car> getNearByCabs(@RequestBody Map<String, Object> srcLocation) {
        Double[] currentLocations = locationConverter.convert((String) srcLocation.get("srcLocation"));
        return carService.findNearByCab(currentLocations[0], currentLocations[1]);
    }

    @PutMapping("/ride/feedback")
    public ResponseEntity<Response> feedback(@RequestBody Map<String, Object> request) {
        Response response = feedbackService.giveFeedBack(
                (Integer) request.get("rideId"),
                objectMapper.convertValue(request.get("feedback"), new TypeReference<Feedback>() {
                })
        );
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/home")
    public String getMessage() {
        return "Welcome ";
    }

    @GetMapping("/getAll")
    public List<Customer> getAllCustomer() {
        return customerService.findAllCustomers();
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Response> deleteCustomer(@PathVariable("id") Integer customerId) {
        Response response = customerService.deleteCustomer(customerId);
        return new ResponseEntity<>(response, response.isStatus() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/getAllWithFilter")
    public ResponseEntity<Response> getCustomersWithFilter(
            @RequestParam(name = "filterTxt", required = false, defaultValue = "") String filterTxt,
            @RequestParam(name = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(name = "size", required = false, defaultValue = "5") Integer size,
            @RequestParam(name = "sortingColumn", required = false, defaultValue = "") String sortingColumn,
            @RequestParam(name = "sortOrder", required = false, defaultValue = "asc") String sortOrder
    ) {
        System.out.println("size => " + size + "   pageNo => " + page);
        Response response = customerService.getAllCustomerWithFilterAndSorting(filterTxt, page, size, sortingColumn, sortOrder);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/updatePassword")
    public ResponseEntity<Response> updateCustomerPassword(@RequestBody Map<String, Object> updateRequest) {
        Response response = new Response();
        try {
            Integer customerId = (Integer) updateRequest.get("customerId");
            String oldPassword = (String) updateRequest.get("oldPassword");
            String newPassword = (String) updateRequest.get("newPassword");

            if (customerId != null && customerId != null && customerId != null) {
                return new ResponseEntity<>(customerService.updatePassword(customerId, oldPassword, newPassword), HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.getErrorMessages().add("some fields are missing or incorrect data types found");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

        } catch (Exception e) {
            response.setStatus(false);
            response.getErrorMessages().add("some fields are missing or incorrect data types found");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
}
