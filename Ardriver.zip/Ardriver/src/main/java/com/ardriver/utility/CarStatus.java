package com.ardriver.utility;

public enum CarStatus {
    ONLINE,
    OFFLINE,
    DRIVING
}
