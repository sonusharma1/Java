package com.ardriver.utility;


import com.ardriver.model.Address;
import com.ardriver.model.Ride;
import com.ardriver.repository.AddressRepository;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.border.DottedBorder;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.property.TextAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class PdfGenerator {

    @Autowired
    private AddressRepository addressRepository;

    public byte[] generatePdf(Ride ride) {

        DeviceRgb headingColor = new DeviceRgb(26, 32, 44);
        DeviceRgb textColor = new DeviceRgb(89, 93, 98);
        DeviceRgb bgColor = new DeviceRgb(235, 239, 255);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        PdfWriter pdfWriter = new PdfWriter(byteArrayOutputStream);
        PdfDocument pdfDocument = new PdfDocument(pdfWriter);

        Document document = new Document(pdfDocument);

        Paragraph paragraph = new Paragraph();
        paragraph.add("Trip Invoice");
        paragraph.setTextAlignment(TextAlignment.CENTER);
        paragraph.setPaddingBottom(10);
        paragraph.setFontSize(15);
        document.add(((Paragraph)createParagraph("Trip Invoice")));

        Paragraph invoiceDatePara = new Paragraph().add("Invoice Date : " + ride.getDate()).setTextAlignment(TextAlignment.RIGHT).setFontColor(headingColor);
        document.add(invoiceDatePara);

        document.add(new Paragraph("Driver Details").setFontColor(headingColor).setMarginBottom(-2).setPaddingBottom(0));
        Paragraph driverPara = new Paragraph()
                .add(
                        ride.getCar().getDriver().getDriverName() + "\n" +
                                ride.getCar().getCarType() + "\n" +
                                ride.getCar().getLicenseNumberPlate()
                )
                .setFontColor(textColor)
                .setPaddingTop(0);
        document.add(driverPara);

        document.add(new Paragraph("Customer Details").setFontColor(headingColor).setMarginBottom(-2).setPaddingTop(5));
        Paragraph customerPara = new Paragraph()
                .add(
                        ride.getCustomer().getCustomerName() + "\n" +
                                ride.getCustomer().getMobileNo() + "\n" +
                                ride.getCustomer().getEmail()
                )
                .setFontColor(textColor)
                .setPaddingTop(0);
        document.add(customerPara);

        Table table2 = new Table(1);
        table2.addCell(new Cell().add("Pickup Address : \n").setBorder(Border.NO_BORDER).setFontColor(headingColor))
                .addCell(new Cell().add(getAddress(ride.getSourceLocation())).setBorder(Border.NO_BORDER).setFontColor(textColor)).setWidthPercent(70);
        table2.addCell(new Cell().add("Destination Address : \n").setBorder(Border.NO_BORDER).setFontColor(headingColor))
                .addCell(new Cell().add(getAddress(ride.getDestLocation())).setBorder(Border.NO_BORDER).setFontColor(textColor));
        table2.setMarginBottom(15);
        table2.setMarginTop(15);
        document.add(table2);

        Table fareTable = new Table(2);
        fareTable.addCell(new Cell().add("Description ").setBorder(Border.NO_BORDER).setFontColor(headingColor).setBackgroundColor(bgColor).setPaddings(5,3,5,3));
        fareTable.addCell(new Cell().add("Amount").setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setFontColor(headingColor).setBackgroundColor(bgColor).setPaddings(5,3,5,3));

        fareTable.addCell(new Cell().add("Ride Fee ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor,0.5f)).setPaddings(5,3,5,3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 95 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor,0.5f)).setPaddings(5,3,5,3));

        fareTable.addCell(new Cell().add("CGST 2.5% ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor,0.5f)).setPaddings(5,3,5,3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 2.5 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(textColor,0.5f)).setPaddings(5,3,5,3));

        fareTable.addCell(new Cell().add("SGST 2.5% ").setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(headingColor,0.5f)).setPaddings(5,3,5,3));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare() * 2.5 / 100)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setBorderBottom(new DashedBorder(headingColor,0.5f)).setPaddings(5,3,5,3));

        fareTable.addCell(new Cell().add("Sub Total ").setBorder(Border.NO_BORDER));
        fareTable.addCell(new Cell().add(String.valueOf(ride.getFare())).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER));

        fareTable.setMarginTop(20);
        document.add(fareTable);

        document.close();
        return byteArrayOutputStream.toByteArray();
    }

    public String getAddress(String location) {

        Address address = addressRepository.findByGeoLocation(location);
        if (address != null)
            return address.getPlaceAddress();
        else
            return location;
    }

    private IBlockElement createParagraph(String text) {
        return new Paragraph(text);
    }
}
