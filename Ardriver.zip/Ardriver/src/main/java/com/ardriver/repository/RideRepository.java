package com.ardriver.repository;

import com.ardriver.model.Ride;
import com.ardriver.utility.CarType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface RideRepository extends JpaRepository<Ride,Integer>, JpaSpecificationExecutor<Ride> {

    @Query("select r from Ride r WHERE r.car.carType = :carType")
    List<Ride> findByCarType(@Param("carType") CarType carType);

    List<Ride> findByTraveledDistanceLessThan(Double traveledDistance);

    @Query("select r from Ride r WHERE r.customer.customerId = :customerId")
    List<Ride> findRides(@Param("customerId") Integer customerId);

    /*@Query("select count from Rides ")
    Integer findNoOfRidesWithinAMonth(int customerId, LocalDate fromDate, LocalDate toDate);*/

    @Query("SELECT COUNT(r) FROM Ride r WHERE MONTH(r.date) = MONTH(CURRENT_DATE) AND YEAR(r.date) = YEAR(CURRENT_DATE)")
    long countRidesForCurrentMonth();

    @Query("SELECT COUNT(r) FROM Ride r WHERE r.date BETWEEN :startDate AND :endDate")
    long countRidesForPreviousMonth(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT SUM(r.fare) FROM Ride r WHERE MONTH(r.date) = MONTH(CURRENT_DATE) AND YEAR(r.date) = YEAR(CURRENT_DATE)")
    Double sumFareForCurrentMonth();

    @Query("SELECT SUM(r.fare) FROM Ride r WHERE r.date BETWEEN :startDate AND :endDate")
    Double sumFareForPreviousMonth(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT r FROM Ride r WHERE r.date BETWEEN :fromDate AND :toDate")
    Page<Ride> getRidesBetweenDates(
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            Pageable pageable
    );
}
