// package com.ardriver.security;
//
// import io.jsonwebtoken.Claims;
// import io.jsonwebtoken.Jwt;
// import io.jsonwebtoken.Jwts;
// import io.jsonwebtoken.SignatureAlgorithm;
// import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
// import org.springframework.security.core.Authentication;
// import org.springframework.stereotype.Component;
//
// import java.util.Date;
//
// @Component
// public class JwtTokenGenerator {
//
//     public String generateToken(Authentication authentication) {
//         String username = authentication.getName();
//         Date currentDate = new Date();
//         Date expireDate = new Date(currentDate.getTime() + 70000);
//         String token = Jwts.builder()
//                 .setSubject(username)
//                 .setIssuedAt(new Date())
//                 .setExpiration(expireDate)
//                 .signWith(SignatureAlgorithm.HS512, "ardriver")
//                 .compact();
//         return token;
//     }
//
//     public String getUserName(String token) {
//         Claims claims = Jwts.parser()
//                 .setSigningKey("ardriver")
//                 .parseClaimsJws(token)
//                 .getBody();
//         return claims.getSubject();
//     }
//
//     public Boolean validateToken(String token) {
//         try {
//             System.out.println(token);
//             Jwts.parser().setSigningKey("ardriver").parseClaimsJws(token);
//             return true;
//         } catch (Exception exception) {
//             throw new AuthenticationCredentialsNotFoundException("JWT was expired or incorrect");
//         }
//     }
// }
