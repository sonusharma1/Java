package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Address;
import com.ardriver.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
    private AddressRepository addressRepository;

    @Override
    public Response addAddress(Address address) {
        Response response = new Response();
        try {
            Address savedAddress = addressRepository.save(address);
            response.setStatus(true);
            response.setResponseData(savedAddress);
            return response;
        } catch (Exception e) {
            response.setStatus(false);
            response.getErrorMessages().add("Error while saving address.");
            return response;
        }
    }
}
