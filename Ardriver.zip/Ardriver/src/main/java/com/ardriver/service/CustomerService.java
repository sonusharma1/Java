package com.ardriver.service;

import com.ardriver.dto.FilterData;
import com.ardriver.dto.Response;
import com.ardriver.model.Customer;
import com.ardriver.model.Ride;

import java.util.List;
import java.util.Map;

public interface CustomerService {
    Response saveCustomer(Customer customer);

    Response updateCustomer(Customer customer);

    Response deleteCustomer(Integer customerid);

    List<Customer> findCustomersNameStartsWith(String customerName);

    List<Ride> findCustomerRides(Integer customerId);

    List<Customer> findCustomerByNameOrEmail(String customerName, String email);

    List<Customer> findByEmailDomain(String emailDomain);

    List<Customer> findCustomersByName(String customerName);

    Customer findCustomerById(Integer id);

    List<Customer> findAllCustomers();

    // Transforming and Aggregating
    Map<Customer, Double> getCustomersWithTotalTraveledDist();

    Response isRegisteredCustomer(String customerEmail, String password);

    Response getAllCustomerWithFilterAndSorting(String filterTxt, Integer page, Integer size, String sortingColumn, String sortOrder);

    Response updatePassword(Integer customerId, String oldPassword, String newPassword);
}
