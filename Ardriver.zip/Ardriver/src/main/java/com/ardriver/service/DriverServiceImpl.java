package com.ardriver.service;

import com.ardriver.dto.AuthenticationDto;
import com.ardriver.dto.Response;
import com.ardriver.model.*;
import com.ardriver.repository.CarRepository;
import com.ardriver.repository.DriverRepository;
import com.ardriver.specifications.FilterSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverServiceImpl implements DriverService {

    public static final Logger LOGGER = LogManager.getLogger(DriverServiceImpl.class);
    @Autowired
    private DriverRepository driverRepository;
    @Autowired
    private CarRepository carRepository;

    @Transactional
    @Override
    public Boolean addDriver(Driver driver) {
        //driverRepository.addDriver(driver.getDriverId(), driver.getDriverName(), driver.getLicenceNo());
        Driver save = driverRepository.save(driver);
        LOGGER.info("Driver's detail saved :)");
        return true;
    }

    //@Transactional
    @Override
    public Driver findDriver(Integer id) {
        Driver driver = driverRepository.findDriverById(id);
        LOGGER.info(driver);
        return driver;
    }

    @Transactional
    @Override
    public Boolean updateDriverName(Integer driverId, String driverName) {
        Driver driver = driverRepository.findDriverById(driverId);
        if (driver != null) {
            driverRepository.updateDriverName(driverId, driverName);
            LOGGER.info("Driver's name changed :)");
            return true;
        }
        return false;
    }

    @Transactional
    @Override
    public Boolean deleteDriverById(Integer driverId) {
        // driverRepository.deleteDriver(driverId);
        driverRepository.deleteById(driverId);
        LOGGER.info("Driver's detail deleted :)");
        return true;
    }

    // Sorting and Limiting
    @Override
    public List<Driver> getTopThreeDriverWithHighestRating() {
        List<Driver> drivers = driverRepository.findAll();
        return drivers.stream()
                .sorted(
                        (d1,d2) -> d2.getDriverRating().compareTo(d1.getDriverRating())
                )
                .limit(3)
                .collect(Collectors.toList());
    }

    @Override
    public Boolean isRegisteredPartner(AuthenticationDto authDto) {
        Driver driver = driverRepository.findByEmailAndPassword(authDto.getEmail(), authDto.getPassword());
        return driver != null;
    }

    @Override
    public List<Ride> findRides(Integer driverId) {
        return carRepository.findByDriverId(driverId).getRides();
    }

    @Override
    public Response findAllDrivers(String filterTxt, Integer page, Integer size) {
        Response response = new Response();
        response.setStatus(true);

        Sort sort = Sort.by(Sort.Order.asc(Driver_.DRIVER_ID));
        // for paging
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Driver> driverPage = driverRepository.findAll(
                FilterSpecification.searchOnAllFields(filterTxt,Driver.class),
                pageable
        );

        List<Driver> driverList = driverPage.getContent();
        response.setResponseData(driverList);
        response.setPageable(driverPage.getTotalPages());

        return response;
    }
}
