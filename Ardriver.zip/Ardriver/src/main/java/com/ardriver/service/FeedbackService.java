package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Feedback;

public interface FeedbackService {
    Response giveFeedBack(Integer rideId, Feedback feedback);
}
