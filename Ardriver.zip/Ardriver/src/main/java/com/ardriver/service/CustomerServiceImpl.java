package com.ardriver.service;

import com.ardriver.dto.FilterData;
import com.ardriver.dto.Response;
import com.ardriver.model.Customer;
import com.ardriver.model.Customer_;
import com.ardriver.model.Ride;
import com.ardriver.repository.CustomerRepository;
import com.ardriver.repository.RideRepository;
import com.ardriver.specifications.FilterSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Validated
public class CustomerServiceImpl implements CustomerService {

    public static final Logger log = LogManager.getLogger(CustomerServiceImpl.class);

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private RideRepository rideRepository;

    /*@Autowired
    private CustomerDao customerDao;*/

    @Override
    public Response saveCustomer(Customer customer) {
        Response response = new Response();
        try {
            Customer savedCustomer = customerRepository.save(customer);
            log.info("customer saved :)");
            response.setStatus(true);
            response.setResponseData(customer);
            return response;
        }
        // if any error occurs
        catch (Exception ex) {
            log.error("customer not saved. {}", ex);
            response.getErrorMessages().add("customer not saved");
            return response;
        }
    }

    @Transactional
    @Override
    public Response updateCustomer(Customer customer) {
        Response response = new Response();
        Customer foundCustomer = customerRepository.findById(customer.getCustomerId()).get();
        if (foundCustomer != null) {
            BeanUtils.copyProperties(customer, foundCustomer);
            response.setStatus(true);
            response.setResponseData(foundCustomer);
            log.info("Customer details updated");
            return response;
        } else {
            log.error("Customer not found");
            response.getErrorMessages().add("customer updation failed");
            return response;
        }
    }

    @Transactional
    @Override
    public Response deleteCustomer(Integer customerid) {
        Response response = new Response();

        Customer customer = findCustomerById(customerid);
        if (customer != null) {
            customer.getRides().forEach(ride -> {

                ride.getCar().getRides().remove(ride);
                ride.setCar(null);

                ride.setCustomer(null);
                rideRepository.save(ride);

                rideRepository.deleteById(ride.getRideId());
            });
            customerRepository.deleteById(customerid);

        }

        if (findCustomerById(customerid) != null) {
            response.getErrorMessages().add("Customer not deleted");
            return response;
        } else {
            response.setStatus(true);
            response.getErrorMessages().add("Customer Deleted Successfully");
            return response;
        }
    }

    @Override
    public List<Customer> findCustomersNameStartsWith(String customerName) {
        return customerRepository.findByCustomerNameLike(customerName + "%");
    }

    @Transactional
    @Override
    public List<Ride> findCustomerRides(Integer customerId) {

        // return customerRepository.findById(customerId)
        //         .map(Customer::getRides)
        //         .orElse(Collections.emptyList());

        return rideRepository.findRides(customerId);
    }

    @Override
    public List<Customer> findCustomerByNameOrEmail(String customerName, String email) {
        // return customerDao.findCustomerByNameOrEmail(customerName, email);
        // return customerRepository.findAll(CustomerSpecifications.hasNameOrEmail(customerName, email));
        return null;
    }

    @Override
    public List<Customer> findByEmailDomain(String emailDomain) {
        // return customerDao.findByEmailDomain(emailDomain);
        // OR
        // return customerRepository.findAll(CustomerSpecifications.hasEmailDomain(emailDomain));
        return null;
    }

    @Override
    public List<Customer> findCustomersByName(String customerName) {
        /*List<Customer> customerList = customerRepository.findAll(CustomerSpecifications.hasName(customerName));
        return customerList;*/
        return null;
    }

    @Override
    public Customer findCustomerById(Integer id) {
        return customerRepository.findById(id).orElse(null);
    }

    @Override
    public List<Customer> findAllCustomers() {
        return customerRepository.findAll();
        /*return customers.stream()
                .map(customer -> {
                    customer.setPassword(passwordEncoder.);
                    return customer;
                }).toList();*/
    }

    // Transforming and Aggregating
    @Override
    public Map<Customer, Double> getCustomersWithTotalTraveledDist() {
        List<Customer> customers = customerRepository.findAll();

        return customers
                .stream()
                .collect(Collectors.toMap(
                        customer -> customer, // KEY
                        customer -> customer.getRides() // VALUE (returns sum(customer.List<Rides>.traveledDist)
                                .stream()
                                .mapToDouble(Ride::getTraveledDistance)
                                .sum()
                ));
    }

    @Override
    public Response isRegisteredCustomer(String customerEmail, String password) {
        Response response = new Response();
        Customer customer = customerRepository.findByEmailAndPassword(customerEmail, password);
        log.info("customer login " + (customer != null ? "success" : "failed"));
        response.setStatus(customer != null);
        response.setResponseData(customer);
        return response;
    }

    @Override
    public Response getAllCustomerWithFilterAndSorting(String filterTxt, Integer page, Integer size, String sortingColumn, String sortOrder) {

        Response response = new Response();
        response.setStatus(true);

        // for sorting
        Sort sort = Sort.by(Sort.Order.asc(Customer_.CUSTOMER_ID));
        if (sortingColumn != null && !sortingColumn.equals("")) {
            if (sortOrder.equals("asc"))
                sort = Sort.by(Sort.Order.asc(sortingColumn));
            else
                sort = Sort.by(Sort.Order.desc(sortingColumn));
        }

        // for paging
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Customer> customerPage = customerRepository.findAll(
                FilterSpecification.searchOnAllFields(filterTxt, Customer.class),
                pageable
        );

        List<Customer> customerList = customerPage.getContent();
        response.setResponseData(customerList);
        response.setPageable(customerPage.getTotalPages());

        /*List<Customer> customers = customerRepository.findAll(
                FilterSpecification.searchOnAllFields(filterTxt, Customer.class),
                sort
        );*/
        System.out.println("No of customers in single page : " + customerList.size() + "\n" + "Total Page : " + customerPage.getTotalPages());
        return response;
    }

    @Override
    public Response updatePassword(Integer customerId, String oldPassword, String newPassword) {
        Response response = new Response();
        Customer customer = customerRepository.findByCustomerIdAndPassword(customerId, oldPassword);
        if (customer != null) {
            customer.setPassword(newPassword);
            customerRepository.save(customer);
            response.setStatus(true);
            response.setResponseData(customer);
            return response;
        } else {
            response.setStatus(false);
            response.getErrorMessages().add("Old password is incorrect");
            return response;
        }
    }
}
