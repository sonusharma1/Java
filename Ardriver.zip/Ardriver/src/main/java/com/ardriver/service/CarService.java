package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Car;
import com.ardriver.model.Driver;
import com.ardriver.utility.CarType;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CarService {

    Response addCar(Car car);

    Car findCarById(int id);

    List<Car> findCarByType(CarType carType);

    List<Car> findNearByCab(Double userLatitude, Double userLongitude);

    Response updateCarLocation(Integer carId, Double[] newLocation);

    Response updateCarStatus(Integer driverId, String carStatus);

    Response findAllCars(String filterTxt, Integer page, Integer size);
}
