package com.ardriver.service;

import com.ardriver.dto.Response;
import com.ardriver.model.Driver;
import com.ardriver.model.Driver_;
import com.ardriver.model.Ride;
import com.ardriver.model.Ride_;
import com.ardriver.repository.RideRepository;
import com.ardriver.specifications.FilterSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private RideRepository rideRepository;

    @Override
    public Response getTripsAndProfits() {
        Response response = new Response();
        response.setStatus(true);

        YearMonth currentYearMonth = YearMonth.now();
        YearMonth previousYearMonth = currentYearMonth.minusMonths(1);
        LocalDate startDate = previousYearMonth.atDay(1);
        LocalDate endDate = previousYearMonth.atEndOfMonth();
//        System.out.println(startDate + " => " + endDate);

        Map<String, Object> tripAndProfitMap = new HashMap<>();
        tripAndProfitMap.put("currentMonthTrips", rideRepository.countRidesForCurrentMonth());
        tripAndProfitMap.put("preMonthTrips", rideRepository.countRidesForPreviousMonth(startDate, endDate));
        tripAndProfitMap.put("currentMonthProfit", rideRepository.sumFareForCurrentMonth());
        tripAndProfitMap.put("prevMonthProfit", rideRepository.sumFareForPreviousMonth(startDate, endDate));

        response.setResponseData(tripAndProfitMap);

        return response;
    }

    @Override
    public Response getAllRides(LocalDate fromDate, LocalDate toDate, Integer pageNo, Integer entryPerPage) {
        Response response = new Response();
        response.setStatus(true);

        System.out.println("FROM DATE TO TODATE => "+fromDate + " => " + toDate);

        Sort sort = Sort.by(Sort.Order.desc(Ride_.DATE));
        // for paging
        Pageable pageable = PageRequest.of(pageNo, entryPerPage, sort);
        Page<Ride> ridesPage = null;

        if (fromDate != null && toDate != null) {
            ridesPage = rideRepository.getRidesBetweenDates(fromDate, toDate, pageable);
        } else {
            ridesPage = rideRepository.findAll(pageable);
        }

        List<Ride> rideList = ridesPage.getContent();

        response.setResponseData(rideList);
        response.setPageable(ridesPage.getTotalPages());

        return response;
    }


}
