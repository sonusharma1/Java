package com.ardriver.dto;

import com.ardriver.model.Ride;
import com.ardriver.utility.CarType;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CarDto {

    private Integer carId;
    private String licenseNumberPlate;
    private CarType carType;
    private Double latitude;
    private Double longitude;
    private DriverDto driver;
    List<RideDto> rideDtos;
}
