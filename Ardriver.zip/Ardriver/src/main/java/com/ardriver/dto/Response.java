package com.ardriver.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Response {

    private boolean status;
    private List<String> errorMessages = new ArrayList<>();
    private Object responseData;
    private Integer pageable;
}
