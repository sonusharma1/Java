package com.ardriver.dto;

import com.ardriver.model.Car;
import com.ardriver.model.Customer;
import com.ardriver.model.Feedback;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RideDto {

    private Integer rideId;

    private String sourceLocation;
    private String destLocation;
    private Double traveledDistance;
    private LocalDate date;
    private Double fare;

    private CarDto carDto;
    private CustomerDto customerDto;

    private FeedbackDto feedbackDto;
}
