package com.ardriver.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FilterData {
    private String filterTxt = "";
    private int page = 1;
    private int size = 10;
    private String sortingColumn;
    private String sortOrder = "asc";
}
