package com.ardriver.constants;

public interface RideConstant {
    public static final String TRIP_INVOICE_PDF = "trip-invoice.pdf";
}
