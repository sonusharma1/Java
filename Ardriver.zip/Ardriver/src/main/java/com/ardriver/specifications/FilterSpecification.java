package com.ardriver.specifications;

import com.ardriver.model.Customer;
import com.ardriver.model.Customer_;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilterSpecification {

    public static <T> Specification<T> searchOnAllFields(String searchTxt, Class<T> entity) {
        return (root, query, criteriaBuilder) -> {

            //getting all attribute/fields of that entity class
            Field[] declaredFields = entity.getDeclaredFields();
            //creating predicates
            Predicate[] predicates = Arrays.stream(declaredFields)
                    // remove fields that contain password, List, Map, Set
                    .filter(field ->
                                    !field.getName().contains("password") &&
                                    !List.class.isAssignableFrom(field.getType()) &&
                                    !Map.class.isAssignableFrom(field.getType()) &&
                                    !Set.class.isAssignableFrom(field.getType())
                    )
                    .map(field -> {
                        if (Integer.class.isAssignableFrom(field.getType()) && searchTxt.matches("-?\\d+")) {
                            return criteriaBuilder.equal(root.get(field.getName()), Integer.parseInt(searchTxt));
                        } else if (String.class.isAssignableFrom(field.getType())) {
                            return criteriaBuilder.like(root.get(field.getName()), searchTxt + "%");
                        }
                        return null;
                    })
                    .filter(Objects::nonNull)
                    // collects as predicate array
                    .toArray(Predicate[]::new);

            return criteriaBuilder.or(predicates);

            /*Predicate namePredicate = criteriaBuilder.like(root.get(Customer_.CUSTOMER_NAME), searchTxt+"%");
            Predicate emailPredicate = criteriaBuilder.like(root.get(Customer_.EMAIL), searchTxt+"%");
            Predicate mobileNoPredicate = criteriaBuilder.like(root.get(Customer_.MOBILE_NO), searchTxt+"%");
            System.out.println(Customer_.MOBILE_NO);
            return criteriaBuilder.or(namePredicate,emailPredicate,mobileNoPredicate);*/
        };
    }
}
