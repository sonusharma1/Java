package com.ardriver.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
//@Builder
@Entity
@Table(name = "customer")
public class Customer {

    @Id
    @SequenceGenerator(name = "customer_id_generator", sequenceName = "customer_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_id_generator")
    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name = "customer_name", length = 30, nullable = false)
    @Size(min = 3, max = 30, message = "Customer name must be between 3-30 character!")
    // @NotBlank
    private String customerName;

    @NotBlank(message = "Email must not be blank")
    @Column(length = 50, nullable = false)
    @Email(message = "email must be a well-formed email address 123")
    private String email;

    @Column(length = 10)
    @Pattern(regexp = "[6-9]\\d{9}", message = "Please provide a valid mobile number")
    @NotBlank(message = "Mobile No must not be blank")
    private String mobileNo;

    @Column(length = 100, nullable = false)
    // @Pattern(regexp = "")
    @NotBlank(message = "Password must not be blank")
    private String password;

    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Ride> rides;

    private Customer(Builder builder) {
        this.customerId = builder.customerId;
        this.customerName = builder.customerName;
        this.email = builder.email;
        this.mobileNo = builder.mobileNo;
        this.password = builder.password;
        this.rides = builder.rides;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Integer customerId;
        private String customerName;
        private String email;
        private String mobileNo;
        private String password;
        private List<Ride> rides;

        public Builder customerId(Integer customerId) {
            this.customerId = customerId;
            return this;
        }
        public Builder customerName(String customerName) {
            this.customerName = customerName;
            return this;
        }
        public Builder email(String email) {
            this.email = email;
            return this;
        }
        public Builder mobileNo(String mobileNo) {
            this.mobileNo = mobileNo;
            return this;
        }
        public Builder password(String password) {
            this.password = password;
            return this;
        }
        public Builder rides(List<Ride> rides) {
            this.rides = rides;
            return this;
        }

        public Customer build() {
            return new Customer(this);
        }

    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", rides=" + rides +
                '}';
    }

    public void addRide(Ride ride) {
        rides.add(ride);
        ride.setCustomer(this); // Set the customer reference in the ride
    }

    /*public static void main(String[] args) {
        String pass = "sonu";
        byte[] bytes = Base64.getEncoder().encode(pass.getBytes(StandardCharsets.UTF_8));
        String s = new String(bytes);
        System.out.println(s);

        byte[] decode = Base64.getDecoder().decode(s);
        String d = new String(decode);
        System.out.println(d);
    }*/
}
